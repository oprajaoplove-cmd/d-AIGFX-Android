package com.aigfx.enhancer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 4102;
    private TextView status;
    private SeekBar strength;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 28);
        page.setBackgroundColor(Color.rgb(13, 17, 28));

        TextView title = new TextView(this);
        title.setText("AIGFX");
        title.setTextColor(Color.WHITE);
        title.setTextSize(32);
        title.setGravity(Gravity.CENTER);
        page.addView(title);

        TextView sub = new TextView(this);
        sub.setText("ANDROID GRAPHICS ENHANCER  •  PROTOTYPE 0.1");
        sub.setTextColor(Color.LTGRAY);
        sub.setTextSize(12);
        sub.setGravity(Gravity.CENTER);
        page.addView(sub);

        status = new TextView(this);
        status.setText("\nStatus: Ready\n\nDevice target: OPPO A6s 5G\nGPU target: Mali-G57-class");
        status.setTextColor(Color.WHITE);
        status.setTextSize(16);
        page.addView(status);

        Button start = new Button(this);
        start.setText("Start screen capture");
        start.setOnClickListener(v -> requestCapture());
        page.addView(start);

        TextView label = new TextView(this);
        label.setText("\nSharpening strength (UI prototype)");
        label.setTextColor(Color.WHITE);
        page.addView(label);

        strength = new SeekBar(this);
        strength.setMax(100);
        strength.setProgress(35);
        page.addView(strength);

        TextView note = new TextView(this);
        note.setText("\nThis first build checks Android screen-capture permission. It does not yet alter the game display. Android does not let an ordinary app replace another game's rendered frames with enhanced frames. The next development step is a capture-and-preview processing pipeline.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(13);
        page.addView(note);

        setContentView(page);
    }

    private void requestCapture() {
        MediaProjectionManager manager =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), CAPTURE_REQUEST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAPTURE_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                status.setText("Status: Screen-capture permission granted.\n\nCapture session is authorized for this app. Frame processing is not implemented in prototype 0.1.");
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                status.setText("Status: Capture permission not granted.");
            }
        }
    }
}
