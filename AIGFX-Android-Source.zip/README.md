# AIGFX — Android Graphics Enhancer

A phone-first Android prototype for experimenting with screen capture and graphics processing.

## Current prototype (0.1)
- Android app shell and AIGFX branding
- Requests Android MediaProjection screen-capture permission
- Basic sharpening-strength UI control (not yet connected to a processing pipeline)
- GitHub Actions workflow that builds a debug APK

## Important limitations
This is **not DLSS**, does not inject into games, and does not currently sharpen or replace another app's live display. Android screen capture permission alone does not provide a supported way for an ordinary app to replace a game's rendered frames. The first milestone is validating capture and building a separate processed preview; a floating control overlay can be explored separately.

## Build on GitHub using only your phone
1. Create a GitHub repository named `AIGFX-Android`.
2. Upload the contents of this ZIP to the repository (keep the folder structure).
3. Open the repository's **Actions** tab.
4. Select **Build AIGFX APK** and tap **Run workflow** (or push to `main`).
5. When it finishes, open the workflow run, scroll to **Artifacts**, and download `AIGFX-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The APK is a debug build for testing. Android may ask you to allow installation from your browser or file manager.
